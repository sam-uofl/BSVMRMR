########################################################################
#            Bootstrap SVM with MRMR for gene selection                #
#                                                                      #
########################################################################

##################### weight.mr starts from here ######################
#' Computation of gene ranking weights through Maximum Relevance and Minimum Redundancy (MRMR) method.


weight.mr <- function (x, y)
{
  this.call = match.call()
  if ((!class(x) == "data.frame")) {
    warning("x must be a data frame and rows as gene names")
  }
  if ((!class(y) == "numeric")) {
    warning("y must be a vector of 1/-1's for two class problems")
  }
  if (!length(y) == ncol(x)) {
    warning("Number of samples in x must have same number of sample labels in y")
  }


  #cls <- as.numeric(y)
  genes <- rownames(x)
  x1 <- as.matrix(x)
  nn <- nrow(x1)
  M <- ncol(x1)
  GeneRankedList <- vector(length = nn)

  qsi <- as.vector((apply(abs(cor(t(x1), method = "pearson",
                                  use = "p") - diag(nrow(x1))), 1, sum))/(nrow(x1) -
                                                                            1))
  idx <- which(y == 1)
  idy <- which(y == -1)
  B = vector(mode = "numeric", nn)
  for (i in 1:nrow(x1))
  {
    f.mes <- (((mean(x1[i, idx]) - mean(x1[i, ]))^2) +
                ((mean(x1[i, idy]) - mean(x1[i, ]))^2))/(var(x1[i,
                                                                idx]) + var(x1[i, idy]))
    B[i] <- f.mes
  }
  rsi <- abs(B)
  weight.mr <- rsi/qsi
  names(weight.mr) <- genes
  GeneRankedList <- sort(-weight.mr, index.return = TRUE)$ix
  #rankvalue <- sort(GeneRankedList, index.return = TRUE)$ix
  #rankscore <- (nn + 1 - rankvalue)/(nn)

  #rankingcriteria <- as.vector(rowSums((M1), na.rm = FALSE, dims = 1))

  names(GeneRankedList) <- genes[GeneRankedList]

  #class(weight.mr ) <- "MRMR weights"
  return(list(weight.mr=weight.mr ,  GeneRankedList= GeneRankedList))
}
################TopGenesMRMR:Function for selecting top genes through MRMR############
#' Selects the top ranked (differentially expressed) genes through MRMR method.
#'
#' Take the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs
#'

TopGenesMRMR <- function(x, y, n){
  this.call = match.call()
  if ((!class(n) == "numeric" & n > nrow(x))) {
    warning("n must be numeric and it should be less than number of rows of x")
  }
  genes.weight <- weight.mr(x, y)$weight.mr
  id <- sort(genes.weight, decreasing=TRUE, index.return = TRUE)$ix
  TopGenes <- genes.weight [id] [1:n]
  return(TopGenes)
}

###############################TopGenesMRMR Ends here################################
#Selection of top ranked (differentially expressed) genes through Support vector machine method.
#############weight.svm: Function for computation of weights through SVM#############

weight.svm <- function (x, y)
{
  this.call = match.call()
  if ((!class(x) == "data.frame")) {
    warning("x must be a data frame and rows as gene names")
  }
  if ((!class(y) == "numeric")) {
    warning("y must be a vector of 1/-1's for two class problems")
  }
  if (!length(y) == ncol(x)) {
    warning("Number of samples in x must have same number of sample labels in y")
  }

  if (!requireNamespace("e1071", quietly = TRUE)) {
    stop("Package \"e1071\" needed for this function to work. Please install it.",
         call. = FALSE)
  }
  y <- as.factor(y)
  genes <- rownames(x)
  x1 <- as.matrix(x)
  nn <- nrow(x1)
  M <- ncol(x1)
  GeneRankedList <- vector(length = nn)
  Indexes=seq(1:nn)
  #usethis::use_package("e1071")
  SvmModel <- svm(t(x1[Indexes, ]), y, cost = 10, cachesize=500,  scale=F, type="C-classification", kernel="linear" )
  a <- SvmModel$coefs
  b <- SvmModel$SV
  SV.weight <- abs((t(a)%*%b)) # absolute value of SVM weights
  GeneRankedList <- sort(-SV.weight, index.return = TRUE)$ix
  names(SV.weight) <- genes
  #rankvalue <- sort(GeneRankedList, index.return = TRUE)$ix
  #rankscore <- (nn + 1 - rankvalue)/(nn)

  #rankingcriteria <- as.vector(rowSums((M1), na.rm = FALSE, dims = 1))

  names(GeneRankedList) <- genes[GeneRankedList]

  #class(SV.weight) <- "SVM weights"
  return(list(SV.weight=SV.weight ,  GeneRankedList= GeneRankedList))
}
###############################weight.svm Ends here################################
##########TopGenesSVM: Function for selection of top genes through SVM############
#' Selects the top ranked (differentially expressed) genes through SVM method.
#'
#' Take the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs


TopGenesSVM <- function(x, y, n){
  this.call = match.call()
  if ((!class(n) == "numeric" & n > nrow(x))) {
    warning("n must be numeric and it should be less than number of rows of x")
  }
  genes.weight <- weight.svm(x, y)$SV.weight
  id <- sort(genes.weight, decreasing=TRUE, index.return = TRUE)$ix
  TopGenes <- genes.weight [id] [1:n]
  return(TopGenes)
}
###############################TopGenesSVM Ends here###############################
###############weight.svm.mrmr: Computation of weights for gene through SVM-MRMR ###
#' Computation weights for gene selection through Support Vector Machine  and Maximum Relevance and Minimum Redundancy (MRMR) methods.
#'
#' Takes the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs.


weight.svm.mrmr <- function (x, y, method, beta)
{

  this.call = match.call()
  if ((!class(x) == "data.frame")) {
    warning("x must be a data frame and rows as gene names")
  }
  if ((!class(y) == "numeric")) {
    warning("y must be a vector of 1/-1's for two class problems")
  }
  if (!length(y) == ncol(x)) {
    warning("Number of samples in x must have same number of sample labels in y")
  }
  if (!class(method)=="character" &
      is.na(match(method, c("Linear", "Quadratic")))==TRUE){
    stop("method of score integration must be either Linear or Quadratic")
  }
  if (!class(beta)=="numeric" & (beta < 0 & beta > 1)) {
    warning("Beta must be numeric and its value must be between 0 and 1")
  }

  if (is.null(beta))
    beta = 0.5
  if (!is.null(beta))
    beta = as.numeric(beta)
  if (is.null(method))
    method = "Linear"

  y <- as.numeric(y)
  genes <- rownames(x)

  if (method=="Linear"){
    MR.weight <- weight.mr(x, y)$weight.mr
    SV.weight <- weight.svm(x, y)$SV.weight
    genes <- names(MR.weight) <- names(SV.weight)
    score <- beta*MR.weight + (1-beta)*SV.weight
    names(score) <- genes

  }

  if (method=="Quadratic"){
    MR.weight <- weight.mr(x, y)$weight.mr
    SV.weight <- weight.svm(x, y)$SV.weight
    genes <- names(MR.weight) <- names(SV.weight)
    idx1 <- sort(as.numeric(MR.weight), decreasing=FALSE, index.return=TRUE)$ix
    idx2 <- sort(as.numeric(SV.weight), decreasing=FALSE, index.return=TRUE)$ix
    score <- (beta * idx1 * MR.weight + (1-beta) * idx2 * SV.weight)/(beta * idx1 + (1-beta) * idx2)
    names(score) <- genes

  }
  class(score) <- "Combined score"
  return(list(score=score, method=method))
}
################################# weight.svm.mrmr Ends here #########################################

#' Selects the top ranked (differentially expressed) genes through SVM-MRMR method.
#'
#' Take the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs


TopGenesSVMRMR <- function (x, y, method, beta, n)
{
  this.call = match.call()
  if ((!class(n) == "numeric" & n > nrow(x))) {
    warning("n must be numeric and it should be less than number of rows of x")
  }
  genes.weight <-  weight.svm.mrmr (x, y, method, beta)$score
  id <- sort(as.vector(genes.weight), decreasing=TRUE, index.return = TRUE)$ix
  TopGenes <- names(genes.weight) [id] [1:n]
  return(TopGenes)
}
###################################### TopGenesSVMRMR Ends here ####################################

##########################Function boot.svm.mrmr.wt for computation of weights######################
#' Computation weights for gene selection through Bootstrap (Boot), Support Vector Machine (SVM)  and Maximum Relevance and Minimum Redundancy (MRMR) methods.
#'

#'
boot.svm.mrmr.wt <- function (x, y, method, beta, nboot)
{

  this.call = match.call()
  if ((!class(x) == "data.frame")) {
    warning("x must be a data frame and rows as gene names")
  }
  if ((!class(y) == "numeric")) {
    warning("y must be a vector of 1/-1's for two class problems")
  }
  if (!length(y) == ncol(x)) {
    warning("Number of samples in x must have same number of sample labels in y")
  }
  if (!class(method)=="character" &
      is.na(match(method, c("Linear", "Quadratic")))==TRUE){
    stop("method of score integration must be either Linear or Quadratic")
  }

  if (!class(beta)=="numeric" & (beta < 0 & beta > 1)) {
    warning("Beta must be numeric and its value must be between 0 and 1")
  }
  if ((!class(nboot) == "numeric")) {
    warning("Number of Bootstrap samples must be numeric")
  }
  if (nboot < 0 & nboot <= 50) {
    warning("Number of Bootstrap samples must be numeric and sufficiently large")
  }
  if (is.null(beta))
    beta = 0.5
  if (!is.null(beta))
    beta = as.numeric(beta)
  if (is.null(method))
    method = "Linear"
  y <- as.numeric(y)
  genes <- rownames(x)
  nn <- nrow(x)
  M <- ncol(x)
  #GeneRankedList <- vector(length = nn)
  boot.mr <- matrix(0, nn, nboot)
  boot.sv <- matrix(0, nn, nboot)
  for (j in 1:nboot) {
    samp <- sample(M, M, replace = TRUE)
    x1 <- x[, samp]
    y1 <- y[samp]
    boot.mr[,j] <- as.numeric(weight.mr(x1, y1)$weight.mr)
    boot.sv[,j] <- as.numeric(weight.svm(x1, y1)$SV.weight)
  }
  MR.weight <- as.vector(weight.mr(x, y)$weight.mr)
  SV.weight <- as.vector(weight.svm(x, y)$SV.weight)
  MR.weight1 <- MR.weight/(apply(boot.mr, 1, mean))
  SV.weight1 <- SV.weight/(apply(boot.sv, 1, mean))
  names(MR.weight1) <- names(SV.weight1) <- genes
  if (method=="Linear"){

    score <- beta*MR.weight1 + (1-beta)*SV.weight1
    names(score) <- genes
  }

  if (method=="Quadratic"){

    idx1 <- rank(as.numeric(MR.weight), na.last = TRUE, ties.method = "random")
    idx2 <- rank(as.numeric(SV.weight), na.last = TRUE, ties.method = "random")
    score <- (beta * idx1 * MR.weight1 + (1-beta) * idx2 * SV.weight1)/(beta * idx1+(1-beta) * idx2)
    names(score) <- genes
    #return(list(score=score, method="Quadratic"))
  }
  class(score) <- "Combined score through Bootstrap"
  return(list(score=score, method=method))
}
############################### boot.svm.mrmr.wt Ends here #######################################
############################# Function for selection of top genes ###############################
#' Selects the top ranked (differentially expressed) genes through Bootstrap-SVM-MRMR method.
#'
#' Take the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs

TopGenesBootSVMRMR <- function (x, y, method, beta, nboot, n)
{
  this.call = match.call()
  if ((!class(n) == "numeric" & n > nrow(x))) {
    warning("n must be numeric and it should be less than number of rows of x")
  }
  genes.weight <-  boot.svm.mrmr.wt (x, y, method, beta, nboot)$score
  id <- sort(as.vector(genes.weight), decreasing=TRUE, index.return = TRUE)$ix
  TopGenes <- names(genes.weight) [id] [1:n]
  return(TopGenes)
}
########################################## TopGenesBootSVMRMR Ends here #######################

##########################Computation p-values for genes through Boot-SVM-MRMR################
#' Computation statistical significance values for gene selection through Bootstrap-Support Vector Machine (SVM)-Maximum Relevance and Minimum Redundancy (MRMR) methods.
#'
#' Takes the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs.


pval.svm.mrmr <- function (x, y, method, beta, nboot, p.adjust.method, plot)
{

  this.call = match.call()
  if ((!class(x) == "data.frame")) {
    warning("x must be a data frame and rows as gene names")
  }
  if ((!class(y) == "numeric")) {
    warning("y must be a vector of 1/-1's for two class problems")
  }
  if (!length(y) == ncol(x)) {
    warning("Number of samples in x must have same number of sample labels in y")
  }
  if (!class(method)=="character" &
      is.na(match(method, c("Linear", "Quadratic")))==TRUE){
    stop("method of score integration must be either Linear or Quadratic")
  }
  if (!class(beta)=="numeric" & (beta < 0 & beta > 1)) {
    warning("Beta must be numeric and its value must be between 0 and 1")
  }
  if ((!class(nboot) == "numeric")) {
    warning("Number of Bootstrap samples must be numeric")
  }
  if (nboot < 0 & nboot <= 50) {
    warning("Number of Bootstrap samples must be numeric and sufficiently large")
  }
  if (!class(p.adjust.method)=="character" & is.na(match(p.adjust.method,
                                                         c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr")))==TRUE){
    stop("Choose proper multiple hypotheis correction method")
  }
  if (is.null(beta))
    beta = 0.5
  if (!is.null(beta))
    beta = as.numeric(beta)
  if (is.null(method))
    method = "Linear"
  if(is.null(p.adjust.method))
    p.adjust.method="BH"
  if(is.null(plot))
    plot=FALSE
  y <- as.numeric(y)
  genes <- rownames(x)
  #g <- as.matrix(x)
  nn <- nrow(x)
  M <- ncol(x)
  #GeneRankedList <- vector(length = nn)
  RankSCor <- matrix(0, nn, nboot)
  BootScor <- matrix(0, nn, nboot)
  if(missing(beta)){
    beta=0.5
  }

  for (i in 1:nboot) {
    samp <- sample(M, M, replace = TRUE)
    x1 <- x[, samp]
    y1 <- y[samp]
    aa <- as.numeric(weight.mr(x1, y1)$weight.mr)
    bb <- as.numeric(weight.svm(x1, y1)$SV.weight)
    wt.mr <- (aa-min(aa))/(max(aa)-min(aa))
    wt.sv <- (bb-min(bb))/(max(bb)-min(bb))

    if(method=="Linear")
    {
      scor <- beta*as.numeric(wt.mr) + (1-beta)*as.numeric(wt.sv)
      #names(score) <- genes
    }

    if (method=="Quadratic"){
      idx1 <- rank(as.numeric(wt.mr), na.last = TRUE, ties.method = "random")
      idx2 <- rank(as.numeric(wt.sv), na.last = TRUE, ties.method = "random")
      scor <- (beta * idx1 * wt.mr + (1-beta) * idx2 * wt.sv)/(beta * idx1+(1-beta) * idx2)
    }
    #names(scor) <- genes
    BootScor[,i] <- scor
    ranks <- rank(-scor, na.last = TRUE, ties.method = "random")
    rankscor <- (nn+1-ranks)/nn
    RankSCor[,i] <- rankscor
  }

  Q3 <- 0.75
  D <- RankSCor - Q3
  pval <- vector(mode = "numeric", length = nn)
  for (i in 1:nn) {
    Z <- D[i, ]
    Z <- Z[Z != 0]
    n1 <- length(Z)
    r <- rank(abs(Z), na.last = TRUE, ties.method = "random")
    tplus <- sum(r[Z > 0])
    etplus <- n1 * (n1 + 1)/8
    vtplus <- n1 * (n1 + 1) * (2 * n1 + 1)/32
    p.value = pnorm(tplus, etplus, sqrt(vtplus), lower.tail = FALSE)
    pval[i] = p.value
  }

  if (is.na(p.adjust.method)==FALSE){
    methods <- c("holm", "hochberg", "hommel", "bonferroni", "BH", "BY", "fdr")
    idm <- match( p.adjust.method, methods)
    pval.adj <- p.adjust(pval, methods[idm], length(pval))
  }
  res <- cbind(apply(RankSCor, 1, sum), pval, pval.adj)
  rownames(res) <- genes
  colnames(res) <- c("Rank score", "P-value", "Adjusted P-value")
  if (plot == TRUE) {
    par(mfrow=c(2,2))
    #as.vector(res[, 1])
    ranks <- sort(as.vector(res[, 1]), decreasing = TRUE, index.return = TRUE)$ix
    plot(1:length(ranks), as.vector(res[, 1])[ranks], main = "Bootstrap Score vs. gene ranks",
         type = "p", xlab = "Genes", ylab = "BootScores of genes", col="red", pch=9)
    lines(lowess(as.vector(res[, 1])[ranks]), col="blue")

    #as.vector(res[, 2])
    ranks <- sort(as.vector(res[, 2]), decreasing = TRUE, index.return = TRUE)$ix
    plot(1:length(ranks), as.vector(res[, 2])[ranks], main = "Rank Score vs. gene ranks",
         type = "p", xlab = "Genes", ylab = "RankScores of genes", col="red", pch=8)
    lines(lowess(as.vector(res[, 2])[ranks]), col="blue")

    #as.vector(res[, 3])
    ranks <- sort(as.vector(res[, 3]), decreasing = FALSE, index.return = TRUE)$ix
    plot(1:length(ranks), as.vector(res[, 3])[ranks], main = "Pvalues vs. gene ranks",
         type = "p", xlab = "Genes", ylab = "P-values of genes", col="red", pch=7)
    lines(lowess(as.vector(res[, 3])), col="blue")

    #as.vector(res[, 3])
    ranks <- sort(as.vector(res[, 4]), decreasing = FALSE, index.return = TRUE)$ix
    plot(1:length(ranks), round(as.vector(res[, 4])[ranks], 3), main = "Adjusted values vs. gene ranks",
         type = "p", xlab = "Genes", ylab = "Adj P-values of genes", col="red", pch=3)
    lines(lowess(as.vector(res[, 4])), col="blue")
  }
  return(res)
}
################################ Function pval.svm.mrmr Ends here ####################################

########################## Selection of Top genes through Boot-SVM-MRMR ##############################
#' Selection of genes based on statistical significance values computed through Bootstrap-Support Vector Machine (SVM)-Maximum Relevance and Minimum Redundancy (MRMR) methods.
#'
#' Takes the gene expression data matrix (rows as genes and coloumns as samples) and vector of class labels of subjects
#' (1: case and -1: control) as inputs.

TopGenesPvalSVMRMR <- function (x, y, method, beta, nboot, p.adjust.method, n)
{
  this.call = match.call()
  if ((!class(n) == "numeric" & n > nrow(x))) {
    warning("n must be numeric and it should be less than number of rows of x")
  }
  genes.weight <- pval.svm.mrmr (x, y, method, beta, nboot, p.adjust.method, plot=FALSE)[,3]
  id <- sort(genes.weight, decreasing=FALSE, index.return = TRUE)$ix
  TopGenes <- names(genes.weight) [id] [1:n]
  return(TopGenes)
}
############################ TopGenesBootSVMRMR Ends here ##########################################
